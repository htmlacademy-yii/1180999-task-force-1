#!/bin/sh

python3 indicator.py >/dev/null 2>&1 & exit
